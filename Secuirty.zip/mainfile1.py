import discord
from discord.ext import commands, tasks
from discord import app_commands
import asyncio, json, os, time
from collections import defaultdict

TOKEN = "MTU2OTgwNjYzMTUxNDkzNTM1OA.GTybj8.1QPsYR8yWiBfOumojnmnJskCgtWcz7f7tUUjaI"
LOG_CHANNEL_NAME = "only-modretaors"

intents = discord.Intents.all()
bot = commands.Bot(command_prefix="/", intents=intents)

# ================= CONFIG الكامل =================
CONFIG = {
    # Anti Nuke - زي securitybot.gg
    "anti_channel_create": {"enabled": True, "limit": 1, "punishment": "Kick"},
    "anti_channel_delete": {"enabled": True, "limit": 1, "punishment": "Kick"},
    "anti_role_create": {"enabled": True, "limit": 1, "punishment": "Kick"},
    "anti_role_delete": {"enabled": True, "limit": 1, "punishment": "Kick"},
    "anti_ban": {"enabled": True, "limit": 1, "punishment": "Kick"},
    "anti_kick": {"enabled": True, "limit": 1, "punishment": "Kick"},
    "anti_bot_add": {"enabled": True, "punishment": "Kick"},
    "anti_prune": {"enabled": True, "punishment": "Ban"},
    "anti_dangerous_role_add": {"enabled": True, "punishment": "Kick"},
    "anti_dangerous_role_update": {"enabled": True, "punishment": "Kick"},
    "anti_invite_link": {"enabled": True, "mode": "DETECT ONLY"},
    "anti_ghost_ping": {"enabled": True},
    "anti_mention": {"enabled": True, "punishment": "Kick"},
    "anti_vanity": {"enabled": True, "punishment": "Kick"},
    # الاضافات الجديدة
    "anti_webhook": {"enabled": True, "punishment": "Ban"},
    "anti_emoji": {"enabled": True, "limit": 3, "punishment": "Kick"},
    "anti_raid": {"enabled": True, "limit": 5, "punishment": "Ban"},
    "anti_spam": {"enabled": True, "limit": 5, "punishment": "Timeout"},
    "anti_link": {"enabled": True},
    "captcha": {"enabled": True},
    "backup": {"enabled": True},
}

actions = defaultdict(list)
spam_tracker = defaultdict(list)
join_times = []
backup_data = {}

# ================= WHITELIST =================
if not os.path.exists("whitelist.json"):
    with open("whitelist.json", "w") as f: json.dump({"users": [], "roles": []}, f)

def load_wl():
    with open("whitelist.json") as f: return json.load(f)
def save_wl(wl):
    with open("whitelist.json", "w") as f: json.dump(wl, f)

def is_whitelisted(member):
    if not member: return True
    wl = load_wl()
    if member.id in wl["users"]: return True
    for r in getattr(member, "roles", []):
        if r.id in wl["roles"]: return True
    if member.id == member.guild.owner_id: return True
    return False

DANGEROUS = ["administrator", "manage_guild", "ban_members", "kick_members", "manage_channels", "manage_roles", "manage_webhooks", "mention_everyone"]
def has_dangerous_perms(role):
    for p in DANGEROUS:
        if getattr(role.permissions, p, False): return True
    return False

def check_limit(guild_id, user_id, key):
    limit = CONFIG[key].get("limit", 1)
    now = time.time()
    k = (guild_id, user_id, key)
    actions[k] = [t for t in actions[k] if now - t < 10]
    actions[k].append(now)
    return len(actions[k]) >= limit

async def punish(guild, user, reason, punishment):
    ch = discord.utils.get(guild.text_channels, name=LOG_CHANNEL_NAME)
    if not ch and guild.text_channels: ch = guild.text_channels[0]
    member = guild.get_member(user.id) if not isinstance(user, discord.Member) else user
    try:
        if punishment == "Kick" and member: await member.kick(reason=reason)
        elif punishment == "Ban" and member: await member.ban(reason=reason)
        elif punishment == "Timeout" and member: await member.timeout(discord.utils.utcnow() + discord.timedelta(minutes=10), reason=reason)
    except: pass
    if ch:
        e = discord.Embed(title="User Punished", color=0x2b2d31)
        e.add_field(name="User:", value=f"{user}\n`{user.id}`", inline=False)
        e.add_field(name="Time to response:", value="1 second", inline=False)
        e.add_field(name="Reason:", value=reason, inline=False)
        e.add_field(name="Punishment Type:", value=punishment, inline=False)
        await ch.send(embed=e)

async def get_actor(guild, action):
    try:
        async for entry in guild.audit_logs(action=action, limit=1):
            return entry.user, entry
    except: return None, None
    return None, None

def make_backup(guild):
    backup_data[guild.id] = {
        "channels": [(c.name, str(c.type)) for c in guild.channels],
        "roles": [(r.name, r.color.value, r.permissions.value) for r in guild.roles if not r.is_default()],
    }

# ================= ON READY + AUTO BACKUP =================
@bot.event
async def on_ready():
    try:
        synced = await bot.tree.sync()
        print(f"Synced {len(synced)} slash commands - {bot.user}")
    except Exception as e:
        print(e)
    auto_backup.start()

@tasks.loop(hours=1)
async def auto_backup():
    for g in bot.guilds:
        if CONFIG["backup"]["enabled"]:
            make_backup(g)
            print(f"Auto backup done for {g.name}")

# ================= SLASH: WHITELIST =================
whitelist_group = app_commands.Group(name="whitelist", description="Whitelist system")

@whitelist_group.command(name="add_user", description="Add user to whitelist")
@app_commands.default_permissions(administrator=True)
async def wl_add_user(interaction: discord.Interaction, user: discord.Member):
    wl = load_wl()
    if user.id not in wl["users"]: wl["users"].append(user.id)
    save_wl(wl)
    await interaction.response.send_message(f"@{user.name} has been whitelisted in the category **Users: All.**", ephemeral=True)

@whitelist_group.command(name="add_role", description="Add role to whitelist")
@app_commands.default_permissions(administrator=True)
async def wl_add_role(interaction: discord.Interaction, role: discord.Role):
    wl = load_wl()
    if role.id not in wl["roles"]: wl["roles"].append(role.id)
    save_wl(wl)
    await interaction.response.send_message(f"Role **{role.name}** has been whitelisted in the category **Roles: All.**", ephemeral=True)

@whitelist_group.command(name="remove_user", description="Remove user from whitelist")
@app_commands.default_permissions(administrator=True)
async def wl_remove_user(interaction: discord.Interaction, user: discord.Member):
    wl = load_wl()
    if user.id in wl["users"]: wl["users"].remove(user.id)
    save_wl(wl)
    await interaction.response.send_message(f"Removed {user.mention} from whitelist.", ephemeral=True)

@whitelist_group.command(name="remove_role", description="Remove role from whitelist")
@app_commands.default_permissions(administrator=True)
async def wl_remove_role(interaction: discord.Interaction, role: discord.Role):
    wl = load_wl()
    if role.id in wl["roles"]: wl["roles"].remove(role.id)
    save_wl(wl)
    await interaction.response.send_message(f"Removed {role.name} from whitelist.", ephemeral=True)

@whitelist_group.command(name="list", description="Show whitelist")
@app_commands.default_permissions(administrator=True)
async def wl_list(interaction: discord.Interaction):
    wl = load_wl()
    users = ", ".join([f"<@{u}>" for u in wl["users"]]) or "None"
    roles = ", ".join([f"<@&{r}>" for r in wl["roles"]]) or "None"
    e = discord.Embed(title="Whitelist", color=0x5865F2)
    e.add_field(name="Users", value=users, inline=False)
    e.add_field(name="Roles", value=roles, inline=False)
    await interaction.response.send_message(embed=e, ephemeral=True)

bot.tree.add_command(whitelist_group)

# ================= SLASH: CONFIG / SET / TOGGLE =================
@bot.tree.command(name="config", description="Show all anti-nuke settings")
@app_commands.default_permissions(administrator=True)
async def config_cmd(interaction: discord.Interaction):
    e = discord.Embed(title="🛡️ Security Config", color=0x5865F2)
    for k, v in CONFIG.items():
        status = "✅" if v.get("enabled") else "❌"
        limit = f" | Limit: {v.get('limit', '-')}" if "limit" in v else ""
        pun = f" | Punishment: {v.get('punishment', v.get('mode','-'))}"
        e.add_field(name=k, value=f"{status}{limit}{pun}", inline=False)
    await interaction.response.send_message(embed=e, ephemeral=True)

@bot.tree.command(name="set_punishment", description="Change punishment type")
@app_commands.choices(punishment=[app_commands.Choice(name="Kick", value="Kick"), app_commands.Choice(name="Ban", value="Ban"), app_commands.Choice(name="Timeout", value="Timeout")])
@app_commands.default_permissions(administrator=True)
async def set_punishment(interaction: discord.Interaction, module: str, punishment: app_commands.Choice[str]):
    if module not in CONFIG:
        await interaction.response.send_message("Module not found! Use /config", ephemeral=True); return
    CONFIG[module]["punishment"] = punishment.value
    await interaction.response.send_message(f"✅ {module} punishment set to **{punishment.value}**", ephemeral=True)
@set_punishment.autocomplete("module")
async def mod_auto(interaction: discord.Interaction, current: str):
    return [app_commands.Choice(name=k, value=k) for k in CONFIG.keys() if current.lower() in k.lower()][:25]

@bot.tree.command(name="set_limit", description="Change limit")
@app_commands.default_permissions(administrator=True)
async def set_limit(interaction: discord.Interaction, module: str, limit: int):
    if module not in CONFIG or "limit" not in CONFIG[module]:
        await interaction.response.send_message("This module has no limit!", ephemeral=True); return
    CONFIG[module]["limit"] = limit
    await interaction.response.send_message(f"✅ {module} limit set to **{limit}**", ephemeral=True)
@set_limit.autocomplete("module")
async def limit_auto(interaction: discord.Interaction, current: str):
    mods = [k for k,v in CONFIG.items() if "limit" in v]
    return [app_commands.Choice(name=k, value=k) for k in mods if current.lower() in k.lower()][:25]

@bot.tree.command(name="toggle", description="Enable / Disable a module")
@app_commands.choices(state=[app_commands.Choice(name="ON ✅", value="on"), app_commands.Choice(name="OFF ❌", value="off")])
@app_commands.default_permissions(administrator=True)
async def toggle_cmd(interaction: discord.Interaction, module: str, state: app_commands.Choice[str]):
    if module not in CONFIG:
        await interaction.response.send_message("Module not found!", ephemeral=True); return
    CONFIG[module]["enabled"] = (state.value == "on")
    await interaction.response.send_message(f"✅ {module} is now **{state.value.upper()}**", ephemeral=True)
@toggle_cmd.autocomplete("module")
async def toggle_auto(interaction: discord.Interaction, current: str):
    return [app_commands.Choice(name=k, value=k) for k in CONFIG.keys() if current.lower() in k.lower()][:25]

# ================= SLASH: BACKUP / RESTORE / PANIC / SECURITY =================
@bot.tree.command(name="backup", description="Create manual backup")
@app_commands.default_permissions(administrator=True)
async def backup_cmd(interaction: discord.Interaction):
    make_backup(interaction.guild)
    d = backup_data[interaction.guild.id]
    await interaction.response.send_message(f"✅ Backup saved! {len(d['channels'])} channels, {len(d['roles'])} roles", ephemeral=True)

@bot.tree.command(name="restore", description="Restore server from backup")
@app_commands.default_permissions(administrator=True)
async def restore_cmd(interaction: discord.Interaction):
    g = interaction.guild
    if g.id not in backup_data:
        await interaction.response.send_message("No backup found! Use /backup first", ephemeral=True); return
    await interaction.response.send_message("🔄 Restoring server...", ephemeral=True)
    data = backup_data[g.id]
    existing_roles = [r.name for r in g.roles]
    for name, color, perms in data["roles"]:
        if name not in existing_roles:
            try: await g.create_role(name=name, colour=discord.Color(color), permissions=discord.Permissions(perms))
            except: pass
    existing_ch = [c.name for c in g.channels]
    for name, typ in data["channels"]:
        if name not in existing_ch:
            try:
                if "text" in typ: await g.create_text_channel(name)
                elif "voice" in typ: await g.create_voice_channel(name)
            except: pass
    await interaction.followup.send("✅ Server Restored!", ephemeral=True)

@bot.tree.command(name="panic", description="LOCKDOWN whole server NOW!")
@app_commands.default_permissions(administrator=True)
async def panic_cmd(interaction: discord.Interaction):
    g = interaction.guild
    for ch in g.text_channels:
        try: await ch.set_permissions(g.default_role, send_messages=False)
        except: pass
    await interaction.response.send_message("🚨 PANIC MODE ON - Server Locked! Use /unpanic to unlock", ephemeral=False)

@bot.tree.command(name="unpanic", description="Unlock server")
@app_commands.default_permissions(administrator=True)
async def unpanic_cmd(interaction: discord.Interaction):
    g = interaction.guild
    for ch in g.text_channels:
        try: await ch.set_permissions(g.default_role, send_messages=None)
        except: pass
    await interaction.response.send_message("✅ Server Unlocked", ephemeral=True)

@bot.tree.command(name="security", description="Show full security dashboard")
@app_commands.default_permissions(administrator=True)
async def security_cmd(interaction: discord.Interaction):
    e = discord.Embed(title="🛡️ SECURITY DASHBOARD", color=0x00FF00, description="Your server is protected")
    e.add_field(name="Anti-Nuke", value="✅ Channel / Role / Ban / Kick", inline=False)
    e.add_field(name="Anti-Raid", value="✅ Auto-Lockdown + Suspicious Check", inline=False)
    e.add_field(name="Anti-Webhook / Emoji / Spam / Link", value="✅ Enabled", inline=False)
    e.add_field(name="Backup System", value="✅ Auto every 1h + /restore", inline=False)
    e.add_field(name="Panic Mode", value="Use /panic to lock all", inline=False)
    await interaction.response.send_message(embed=e, ephemeral=True)

# ================= ANTI NUKE EVENTS =================
@bot.event
async def on_guild_channel_create(channel):
    await asyncio.sleep(0.5)
    actor, _ = await get_actor(channel.guild, discord.AuditLogAction.channel_create)
    if not actor or actor.bot or is_whitelisted(channel.guild.get_member(actor.id)): return
    if not CONFIG["anti_channel_create"]["enabled"]: return
    if check_limit(channel.guild.id, actor.id, "anti_channel_create"):
        try: await channel.delete(reason="Anti Channel Create")
        except: pass
        await punish(channel.guild, actor, "Creating Channels", CONFIG["anti_channel_create"]["punishment"])

@bot.event
async def on_guild_channel_delete(channel):
    actor, _ = await get_actor(channel.guild, discord.AuditLogAction.channel_delete)
    if not actor or actor.bot or is_whitelisted(channel.guild.get_member(actor.id)): return
    if not CONFIG["anti_channel_delete"]["enabled"]: return
    if check_limit(channel.guild.id, actor.id, "anti_channel_delete"):
        await punish(channel.guild, actor, "Deleting Channels", CONFIG["anti_channel_delete"]["punishment"])

@bot.event
async def on_guild_role_create(role):
    await asyncio.sleep(0.5)
    actor, _ = await get_actor(role.guild, discord.AuditLogAction.role_create)
    if not actor or actor.bot or is_whitelisted(role.guild.get_member(actor.id)): return
    if not CONFIG["anti_role_create"]["enabled"]: return
    if check_limit(role.guild.id, actor.id, "anti_role_create"):
        try: await role.delete(reason="Anti Role Create")
        except: pass
        await punish(role.guild, actor, "Creating Roles", CONFIG["anti_role_create"]["punishment"])

@bot.event
async def on_guild_role_delete(role):
    actor, _ = await get_actor(role.guild, discord.AuditLogAction.role_delete)
    if not actor or actor.bot or is_whitelisted(role.guild.get_member(actor.id)): return
    if not CONFIG["anti_role_delete"]["enabled"]: return
    if check_limit(role.guild.id, actor.id, "anti_role_delete"):
        await punish(role.guild, actor, "Deleting Roles", CONFIG["anti_role_delete"]["punishment"])

@bot.event
async def on_guild_role_update(before, after):
    if has_dangerous_perms(after) and not has_dangerous_perms(before):
        actor, _ = await get_actor(after.guild, discord.AuditLogAction.role_update)
        if not actor or actor.bot or is_whitelisted(after.guild.get_member(actor.id)): return
        if not CONFIG["anti_dangerous_role_update"]["enabled"]: return
        try: await after.edit(permissions=before.permissions, reason="Anti Dangerous Permission")
        except: pass
        await punish(after.guild, actor, "Dangerous Role Permission Update", CONFIG["anti_dangerous_role_update"]["punishment"])

@bot.event
async def on_member_ban(guild, user):
    actor, _ = await get_actor(guild, discord.AuditLogAction.ban)
    if not actor or actor.bot or is_whitelisted(guild.get_member(actor.id)): return
    if not CONFIG["anti_ban"]["enabled"]: return
    if check_limit(guild.id, actor.id, "anti_ban"):
        await punish(guild, actor, "Banning Members", CONFIG["anti_ban"]["punishment"])

@bot.event
async def on_member_remove(member):
    await asyncio.sleep(0.5)
    actor_kick, _ = await get_actor(member.guild, discord.AuditLogAction.kick)
    if actor_kick and not actor_kick.bot and not is_whitelisted(member.guild.get_member(actor_kick.id)):
        if CONFIG["anti_kick"]["enabled"] and check_limit(member.guild.id, actor_kick.id, "anti_kick"):
            await punish(member.guild, actor_kick, "Kicking Members", CONFIG["anti_kick"]["punishment"]); return
    actor_prune, _ = await get_actor(member.guild, discord.AuditLogAction.prune)
    if actor_prune and not actor_prune.bot and not is_whitelisted(member.guild.get_member(actor_prune.id)):
        if CONFIG["anti_prune"]["enabled"]:
            await punish(member.guild, actor_prune, "Pruning Members", CONFIG["anti_prune"]["punishment"])

@bot.event
async def on_guild_update(before, after):
    if before.vanity_url_code != after.vanity_url_code and CONFIG["anti_vanity"]["enabled"]:
        actor, _ = await get_actor(after, discord.AuditLogAction.guild_update)
        if actor and not actor.bot and not is_whitelisted(after.get_member(actor.id)):
            await punish(after, actor, "Changing Vanity URL", CONFIG["anti_vanity"]["punishment"])

@bot.event
async def on_webhooks_update(channel):
    await asyncio.sleep(0.5)
    actor, _ = await get_actor(channel.guild, discord.AuditLogAction.webhook_create)
    if actor and not actor.bot and not is_whitelisted(channel.guild.get_member(actor.id)):
        if CONFIG["anti_webhook"]["enabled"]:
            for wh in await channel.webhooks():
                if wh.user == actor:
                    try: await wh.delete()
                    except: pass
            await punish(channel.guild, actor, "Creating Webhooks", CONFIG["anti_webhook"]["punishment"])

@bot.event
async def on_guild_emojis_update(guild, before, after):
    if len(after) < len(before):
        actor, _ = await get_actor(guild, discord.AuditLogAction.emoji_delete)
        if actor and not actor.bot and not is_whitelisted(guild.get_member(actor.id)):
            if CONFIG["anti_emoji"]["enabled"]:
                await punish(guild, actor, "Deleting Emojis", CONFIG["anti_emoji"]["punishment"])

# ================= MEMBER JOIN - BOT + RAID + SUSPICIOUS =================
@bot.event
async def on_member_join(member):
    # ANTI BOT ADD
    if member.bot and CONFIG["anti_bot_add"]["enabled"]:
        actor, _ = await get_actor(member.guild, discord.AuditLogAction.bot_add)
        if actor and not actor.bot and not is_whitelisted(member.guild.get_member(actor.id)):
            try: await member.kick(reason="Anti Bot Add")
            except: pass
            await punish(member.guild, actor, "Adding Bots", CONFIG["anti_bot_add"]["punishment"])
            return
    # ANTI RAID
    global join_times
    now = time.time()
    join_times = [t for t in join_times if now - t < 10]
    join_times.append(now)
    if len(join_times) >= CONFIG["anti_raid"]["limit"] and CONFIG["anti_raid"]["enabled"]:
        for ch in member.guild.text_channels:
            try: await ch.set_permissions(member.guild.default_role, send_messages=False)
            except: pass
        ch = discord.utils.get(member.guild.text_channels, name=LOG_CHANNEL_NAME)
        if ch: await ch.send("🚨 **RAID DETECTED!** Server auto-locked. Use `/unpanic` to unlock")
        join_times = []
    # SUSPICIOUS
    age = (discord.utils.utcnow() - member.created_at).days
    if age < 7 and CONFIG["captcha"]["enabled"]:
        ch = discord.utils.get(member.guild.text_channels, name=LOG_CHANNEL_NAME)
        if ch: await ch.send(f"⚠️ Suspicious account joined: {member.mention} - Age: {age} days")

@bot.event
async def on_member_update(before, after):
    new_roles = [r for r in after.roles if r not in before.roles]
    for role in new_roles:
        if has_dangerous_perms(role) and CONFIG["anti_dangerous_role_add"]["enabled"]:
            actor, _ = await get_actor(after.guild, discord.AuditLogAction.member_role_update)
            if actor and not actor.bot and not is_whitelisted(after.guild.get_member(actor.id)):
                try: await after.remove_roles(role, reason="Anti Dangerous Role Add")
                except: pass
                await punish(after.guild, actor, "Adding Dangerous Role", CONFIG["anti_dangerous_role_add"]["punishment"])

# ================= MESSAGE - SPAM / LINK / INVITE / MENTION / GHOST =================
@bot.event
async def on_message(message):
    if message.author.bot or not message.guild: return
    if is_whitelisted(message.author): return

    # ANTI SPAM
    if CONFIG["anti_spam"]["enabled"]:
        k = (message.guild.id, message.author.id)
        now = time.time()
        spam_tracker[k] = [t for t in spam_tracker[k] if now - t < 3]
        spam_tracker[k].append(now)
        if len(spam_tracker[k]) >= CONFIG["anti_spam"]["limit"]:
            try: await message.delete()
            except: pass
            try: await message.author.timeout(discord.utils.utcnow() + discord.timedelta(minutes=10), reason="Spam")
            except: pass
            await message.channel.send(f"{message.author.mention} Stop spamming! Muted 10m", delete_after=5)
            spam_tracker[k] = []
            return

    # ANTI LINK
    if CONFIG["anti_link"]["enabled"] and ("http://" in message.content or "https://" in message.content):
        if "discord.gg" not in message.content and "discord.com" not in message.content:
            await message.delete()
            await message.channel.send(f"{message.author.mention} Links are not allowed!", delete_after=5)
            return

    # ANTI INVITE LINK - DETECT ONLY
    if CONFIG["anti_invite_link"]["enabled"] and ("discord.gg/" in message.content or "discord.com/invite/" in message.content):
        await message.delete()
        await message.channel.send(f"{message.author.mention} Invite links are not allowed! [DETECT ONLY]", delete_after=5)
        return

    # ANTI MENTION
    if CONFIG["anti_mention"]["enabled"] and ("@everyone" in message.content or "@here" in message.content or len(message.mentions) > 5):
        await message.delete()
        await punish(message.guild, message.author, "Mention Everyone", CONFIG["anti_mention"]["punishment"])
        return

@bot.event
async def on_message_delete(message):
    if not message.guild or message.author.bot: return
    if CONFIG["anti_ghost_ping"]["enabled"] and message.mentions:
        if is_whitelisted(message.author): return
        mentions = ", ".join([m.mention for m in message.mentions])
        await message.channel.send(f"👻 {message.author.mention} Ghost Ping Detected! You pinged {mentions} and deleted it.", delete_after=10)

bot.run(TOKEN)